import { IsNotEmpty, IsOptional, IsString, IsUUID } from 'class-validator';

export class CreateWorkshopDto {
  @IsString() @IsNotEmpty() name!: string;
  @IsOptional() @IsUUID() parentId?: string;
  @IsOptional() @IsUUID() managerId?: string;
  @IsOptional() @IsUUID() departmentId?: string;
}
